# Change Log

## [1.1.1] 2018-01-05
 * Update `debug` flag to log requested URLs to render
 * Fix for renderComplete flag
 * Minor bug fixes

## [1.1.0] 2017-10-27
 * Initial release on NPM
